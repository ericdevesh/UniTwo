import { GoogleGenAI, Type } from "@google/genai";

const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const getConversationStarters = async (context: string): Promise<string[]> => {
  try {
    const model = 'gemini-2.5-flash';
    const response = await ai.models.generateContent({
      model,
      contents: `Generate 3 fun, deep, or interesting conversation starters for a long-distance couple or friends hanging out online. 
      Context: ${context}. 
      Keep them short and engaging.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.STRING
          }
        }
      }
    });

    const text = response.text;
    if (!text) return ["How was your day really?", "What's one thing you're looking forward to?", "If we could teleport anywhere right now, where would we go?"];
    
    return JSON.parse(text) as string[];
  } catch (error) {
    console.error("Gemini Conversation Error:", error);
    return ["Tell me about the best part of your day.", "What movie should we watch next?", "What is your favorite shared memory of us?"];
  }
};

export const getMediaRecommendations = async (mood: string): Promise<{title: string, artist: string, reason: string}[]> => {
  try {
    const model = 'gemini-2.5-flash';
    const response = await ai.models.generateContent({
      model,
      contents: `Suggest 3 songs or short videos for a couple feeling "${mood}". 
      Return a JSON array of objects with title, artist (or channel), and a very short reason why.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              artist: { type: Type.STRING },
              reason: { type: Type.STRING }
            }
          }
        }
      }
    });

    const text = response.text;
    if (!text) return [];
    return JSON.parse(text);
  } catch (error) {
    console.error("Gemini Media Error:", error);
    return [];
  }
};

export const generateRoomBackground = async (vibe: string): Promise<string | null> => {
  try {
    // Using flash-image as requested for general generation
    const model = 'gemini-2.5-flash-image';
    const response = await ai.models.generateContent({
      model,
      contents: {
        parts: [
          { text: `A soft, aesthetic, lo-fi style background image for a chat room. Vibe: ${vibe}. No text, dreamy atmosphere, wide aspect ratio.` }
        ]
      }
    });

    // Iterate to find the image part
    for (const part of response.candidates?.[0]?.content?.parts || []) {
        if (part.inlineData) {
            return `data:image/png;base64,${part.inlineData.data}`;
        }
    }
    return null;
  } catch (error) {
    console.error("Gemini Image Gen Error:", error);
    return null;
  }
}
