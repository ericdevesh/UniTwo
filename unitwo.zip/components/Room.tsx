import React, { useState, useEffect } from 'react';
import { User, Message, MediaItem, MediaType, MessageType } from '../types';
import Chat from './Chat';
import MediaPlayer from './MediaPlayer';
import VideoCall from './VideoCall';
import Button from './Button';
import { generateRoomBackground, getMediaRecommendations } from '../services/geminiService';

interface RoomProps {
  user: User;
  onLeave: () => void;
}

// Dummy Data for MVP
const INITIAL_QUEUE: MediaItem[] = [
  {
    id: '1',
    title: 'Big Buck Bunny',
    artist: 'Blender Foundation',
    url: 'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
    thumbnail: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Big_buck_bunny_poster_big.jpg/800px-Big_buck_bunny_poster_big.jpg',
    type: MediaType.VIDEO
  },
  {
    id: '2',
    title: 'Lofi Hip Hop Mix',
    artist: 'Chill Cow',
    url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    thumbnail: 'https://picsum.photos/400/400?grayscale',
    type: MediaType.MUSIC
  }
];

const Room: React.FC<RoomProps> = ({ user, onLeave }) => {
  // State
  const [messages, setMessages] = useState<Message[]>([]);
  const [queue, setQueue] = useState<MediaItem[]>(INITIAL_QUEUE);
  const [currentMediaIndex, setCurrentMediaIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [micMuted, setMicMuted] = useState(false);
  const [cameraOff, setCameraOff] = useState(false);
  const [roomBackground, setRoomBackground] = useState<string>('');
  const [isGeneratingBg, setIsGeneratingBg] = useState(false);
  const [isGettingRecs, setIsGettingRecs] = useState(false);

  // Computed
  const currentMedia = queue[currentMediaIndex] || null;

  // Effects
  useEffect(() => {
    // Simulate Partner Joining
    const timer = setTimeout(() => {
      setMessages(prev => [...prev, {
        id: 'sys-1',
        senderId: 'system',
        senderName: 'System',
        text: 'Partner has joined the room.',
        timestamp: Date.now(),
        type: MessageType.SYSTEM
      }]);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  // Handlers
  const handleSendMessage = (text: string) => {
    const newMsg: Message = {
      id: Date.now().toString(),
      senderId: user.id,
      senderName: user.name,
      text,
      timestamp: Date.now(),
      type: MessageType.USER
    };
    setMessages(prev => [...prev, newMsg]);
  };

  const handleMediaEnd = () => {
    if (currentMediaIndex < queue.length - 1) {
      setCurrentMediaIndex(prev => prev + 1);
    } else {
      setIsPlaying(false);
    }
  };

  const handleGenerateBackground = async () => {
      setIsGeneratingBg(true);
      const bg = await generateRoomBackground("Cosy, warm, sunset view from a high rise apartment window, lo-fi aesthetic");
      if (bg) setRoomBackground(bg);
      setIsGeneratingBg(false);
  };

  const handleGetRecs = async () => {
      setIsGettingRecs(true);
      const recs = await getMediaRecommendations("Relaxed and romantic");
      if (recs.length > 0) {
          // Add dummy items based on recs for MVP demo
          const newItems: MediaItem[] = recs.map((rec, i) => ({
              id: `rec-${Date.now()}-${i}`,
              title: rec.title,
              artist: rec.artist,
              url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3', // Dummy URL
              thumbnail: `https://picsum.photos/400/400?random=${i}`,
              type: MediaType.MUSIC
          }));
          setQueue(prev => [...prev, ...newItems]);
          setMessages(prev => [...prev, {
              id: Date.now().toString(),
              senderId: 'ai',
              senderName: 'UniTwo AI',
              text: `I've added some suggestions to the queue: ${recs.map(r => r.title).join(', ')}`,
              timestamp: Date.now(),
              type: MessageType.AI
          }]);
      }
      setIsGettingRecs(false);
  };

  return (
    <div className="relative w-full h-screen flex flex-col overflow-hidden bg-slate-950">
      {/* Dynamic Background */}
      {roomBackground && (
          <div 
            className="absolute inset-0 z-0 bg-cover bg-center transition-opacity duration-1000 opacity-30" 
            style={{ backgroundImage: `url(${roomBackground})` }}
          />
      )}
      
      {/* Top Bar */}
      <header className="z-10 flex items-center justify-between px-6 py-4 bg-slate-900/60 backdrop-blur-md border-b border-white/5">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 bg-gradient-to-tr from-violet-600 to-pink-500 rounded-xl flex items-center justify-center shadow-lg shadow-violet-500/20">
             <span className="font-bold text-white text-lg">U2</span>
          </div>
          <div>
            <h1 className="font-bold text-slate-100">UniTwo Room</h1>
            <p className="text-xs text-green-400 flex items-center gap-1">
                <span className="block w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                Connected
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
            <Button variant="secondary" onClick={handleGenerateBackground} isLoading={isGeneratingBg} className="text-xs hidden md:flex">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                Set Vibe
            </Button>
            <Button variant="danger" onClick={onLeave} className="text-xs">
                Leave
            </Button>
        </div>
      </header>

      {/* Main Content Grid */}
      <main className="z-10 flex-1 grid grid-cols-1 lg:grid-cols-4 gap-4 p-4 lg:p-6 overflow-hidden">
        
        {/* Left Col: Media Player (Takes 3 cols on large screens) */}
        <div className="lg:col-span-3 flex flex-col gap-4 min-h-0">
          <div className="flex-1 min-h-0 relative">
             <MediaPlayer 
                media={currentMedia}
                isPlaying={isPlaying}
                seekTime={0}
                onPlayPause={setIsPlaying}
                onEnded={handleMediaEnd}
                onTimeUpdate={setCurrentTime}
             />
             
             {/* PiP Video Call Overlay (Draggable ideally, fixed for MVP) */}
             <div className="absolute top-4 right-4 w-32 h-48 md:w-48 md:h-64 shadow-2xl rounded-2xl overflow-hidden border-2 border-slate-800/50">
                <VideoCall 
                    isMuted={micMuted}
                    isVideoOff={cameraOff}
                    onToggleMute={() => setMicMuted(!micMuted)}
                    onToggleVideo={() => setCameraOff(!cameraOff)}
                />
             </div>
          </div>

          {/* Player Controls & Queue Preview */}
          <div className="h-32 bg-slate-900/60 backdrop-blur-md rounded-2xl border border-white/5 p-4 flex flex-col md:flex-row gap-4 items-center">
             <div className="flex-1 w-full">
                <div className="flex items-center justify-between mb-2">
                    <div>
                        <h4 className="font-bold text-white text-sm truncate">{currentMedia?.title || "No Media"}</h4>
                        <p className="text-xs text-slate-400">{currentMedia?.artist}</p>
                    </div>
                    <div className="text-xs font-mono text-slate-400">
                        {Math.floor(currentTime / 60)}:{(currentTime % 60).toFixed(0).padStart(2, '0')}
                    </div>
                </div>
                {/* Progress Bar (Visual only for MVP) */}
                <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-violet-500 w-1/3 animate-pulse"></div>
                </div>
             </div>

             <div className="flex gap-2">
                <Button variant="secondary" onClick={() => setIsPlaying(!isPlaying)}>
                    {isPlaying ? (
                        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
                    ) : (
                        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                    )}
                </Button>
                <Button variant="secondary" onClick={() => {
                     if(currentMediaIndex < queue.length - 1) setCurrentMediaIndex(currentMediaIndex + 1);
                }}>
                    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M6 18l8.5-6L6 6v12zM16 6v12h2V6h-2z"/></svg>
                </Button>
                <Button variant="ghost" onClick={handleGetRecs} isLoading={isGettingRecs} title="AI Suggestions">
                    <svg className="w-5 h-5 text-pink-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.384-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" /></svg>
                </Button>
             </div>
          </div>
        </div>

        {/* Right Col: Chat & Playlist (Tabs ideally, stacked for now) */}
        <div className="lg:col-span-1 min-h-0 flex flex-col gap-4">
             <div className="flex-1 min-h-0">
                 <Chat 
                    messages={messages} 
                    currentUser={user} 
                    onSendMessage={handleSendMessage} 
                 />
             </div>
             
             {/* Queue List */}
             <div className="h-1/3 bg-slate-900/50 backdrop-blur-md rounded-2xl border border-slate-700/50 p-4 overflow-y-auto scrollbar-hide">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">Up Next</h3>
                <div className="space-y-2">
                    {queue.map((item, idx) => (
                        <div 
                            key={item.id} 
                            onClick={() => setCurrentMediaIndex(idx)}
                            className={`flex items-center gap-3 p-2 rounded-lg cursor-pointer transition-colors ${idx === currentMediaIndex ? 'bg-white/10' : 'hover:bg-white/5'}`}
                        >
                            <img src={item.thumbnail} alt="" className="w-10 h-10 rounded-md object-cover" />
                            <div className="overflow-hidden">
                                <p className={`text-sm font-medium truncate ${idx === currentMediaIndex ? 'text-violet-300' : 'text-slate-200'}`}>{item.title}</p>
                                <p className="text-xs text-slate-500 truncate">{item.artist}</p>
                            </div>
                            {idx === currentMediaIndex && (
                                <div className="ml-auto w-2 h-2 rounded-full bg-violet-500 shadow-[0_0_10px_rgba(139,92,246,0.5)]"></div>
                            )}
                        </div>
                    ))}
                </div>
             </div>
        </div>

      </main>
    </div>
  );
};

export default Room;