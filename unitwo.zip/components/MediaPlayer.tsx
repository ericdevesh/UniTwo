import React, { useRef, useEffect, useState } from 'react';
import { MediaItem, MediaType } from '../types';

interface MediaPlayerProps {
  media: MediaItem | null;
  isPlaying: boolean;
  seekTime: number; // Timestamp to seek to
  onPlayPause: (playing: boolean) => void;
  onEnded: () => void;
  onTimeUpdate: (time: number) => void;
}

const MediaPlayer: React.FC<MediaPlayerProps> = ({ 
  media, 
  isPlaying, 
  seekTime, 
  onPlayPause, 
  onEnded,
  onTimeUpdate
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const audioRef = useRef<HTMLAudioElement>(null);
  const [volume, setVolume] = useState(0.8);

  // Sync effect
  useEffect(() => {
    const el = media?.type === MediaType.VIDEO ? videoRef.current : audioRef.current;
    if (!el) return;

    if (isPlaying) {
      el.play().catch(e => console.warn("Autoplay blocked", e));
    } else {
      el.pause();
    }
  }, [isPlaying, media]);

  // Handle media change
  useEffect(() => {
      // Reset logic if needed when media changes
  }, [media]);

  if (!media) {
    return (
      <div className="w-full h-full flex flex-col items-center justify-center bg-black/60 rounded-2xl border border-slate-800 backdrop-blur-sm p-10 text-center">
        <div className="w-20 h-20 bg-slate-800 rounded-full flex items-center justify-center mb-4">
             <svg className="w-8 h-8 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" /></svg>
        </div>
        <h3 className="text-xl font-bold text-slate-300">Nothing Playing</h3>
        <p className="text-slate-500 mt-2">Add songs or videos to the queue to start listening together.</p>
      </div>
    );
  }

  const handleTimeUpdate = (e: React.SyntheticEvent<HTMLMediaElement>) => {
      onTimeUpdate(e.currentTarget.currentTime);
  };

  return (
    <div className="w-full h-full relative rounded-2xl overflow-hidden bg-black group shadow-2xl shadow-violet-900/10">
      {media.type === MediaType.VIDEO ? (
        <video
          ref={videoRef}
          src={media.url}
          className="w-full h-full object-contain"
          onEnded={onEnded}
          onTimeUpdate={handleTimeUpdate}
          onPause={() => onPlayPause(false)}
          onPlay={() => onPlayPause(true)}
        />
      ) : (
        <div className="w-full h-full flex flex-col items-center justify-center relative">
          <img src={media.thumbnail} alt="Album Art" className="absolute inset-0 w-full h-full object-cover opacity-30 blur-xl scale-110" />
          <div className="relative z-10 w-64 h-64 rounded-2xl overflow-hidden shadow-2xl mb-6">
              <img src={media.thumbnail} alt="Album Art" className={`w-full h-full object-cover ${isPlaying ? 'animate-pulse-ring' : ''}`} />
          </div>
          <div className="relative z-10 text-center">
              <h2 className="text-3xl font-bold text-white mb-1 drop-shadow-lg">{media.title}</h2>
              <p className="text-lg text-slate-200 drop-shadow-md">{media.artist}</p>
          </div>
          <audio
            ref={audioRef}
            src={media.url}
            onEnded={onEnded}
            onTimeUpdate={handleTimeUpdate}
            onPause={() => onPlayPause(false)}
            onPlay={() => onPlayPause(true)}
          />
        </div>
      )}

      {/* Overlay Controls (Simple play/pause indicator) */}
      {!isPlaying && (
          <div className="absolute inset-0 flex items-center justify-center bg-black/40 pointer-events-none">
              <div className="w-16 h-16 rounded-full bg-white/20 backdrop-blur-md flex items-center justify-center">
                   <svg className="w-8 h-8 text-white ml-1" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z" /></svg>
              </div>
          </div>
      )}
    </div>
  );
};

export default MediaPlayer;