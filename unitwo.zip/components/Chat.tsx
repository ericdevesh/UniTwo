import React, { useState, useEffect, useRef } from 'react';
import { Message, MessageType, User } from '../types';
import Button from './Button';
import Input from './Input';
import { getConversationStarters } from '../services/geminiService';

interface ChatProps {
  messages: Message[];
  currentUser: User;
  onSendMessage: (text: string) => void;
}

const Chat: React.FC<ChatProps> = ({ messages, currentUser, onSendMessage }) => {
  const [inputText, setInputText] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputText.trim()) {
      onSendMessage(inputText);
      setInputText('');
    }
  };

  const handleAiSpark = async () => {
    setIsAiLoading(true);
    try {
      const suggestions = await getConversationStarters("Two friends hanging out watching videos");
      // Add one suggestion directly to input or pick random
      const random = suggestions[Math.floor(Math.random() * suggestions.length)];
      setInputText(random);
    } catch (e) {
      console.error(e);
    } finally {
      setIsAiLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-900/50 backdrop-blur-md rounded-2xl border border-slate-700/50 overflow-hidden">
      {/* Header */}
      <div className="p-4 border-b border-slate-700/50 flex justify-between items-center bg-slate-900/80">
        <h3 className="font-semibold text-white">Chat Room</h3>
        <button 
          onClick={handleAiSpark} 
          disabled={isAiLoading}
          className="text-xs bg-gradient-to-r from-pink-500 to-violet-500 px-3 py-1 rounded-full text-white font-medium hover:opacity-90 transition-opacity flex items-center gap-1"
          title="Get AI conversation starter"
        >
          {isAiLoading ? (
            <svg className="animate-spin h-3 w-3" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"/></svg>
          ) : (
            <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
          )}
          Spark Topic
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide">
        {messages.length === 0 && (
          <div className="text-center text-slate-500 text-sm mt-10">
            <p>No messages yet.</p>
            <p>Use the spark button to break the ice!</p>
          </div>
        )}
        {messages.map((msg) => {
          const isMe = msg.senderId === currentUser.id;
          const isSystem = msg.type === MessageType.SYSTEM;
          
          if (isSystem) {
             return (
                 <div key={msg.id} className="flex justify-center my-2">
                     <span className="text-xs text-slate-400 bg-slate-800/50 px-2 py-1 rounded-md">{msg.text}</span>
                 </div>
             )
          }

          return (
            <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm shadow-sm ${
                isMe 
                  ? 'bg-violet-600 text-white rounded-br-none' 
                  : 'bg-slate-700 text-slate-100 rounded-bl-none'
              }`}>
                {!isMe && <p className="text-[10px] text-slate-400 mb-1 font-bold">{msg.senderName}</p>}
                <p>{msg.text}</p>
                <p className={`text-[10px] mt-1 text-right ${isMe ? 'text-violet-200' : 'text-slate-400'}`}>
                  {new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                </p>
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-3 bg-slate-900/80 border-t border-slate-700/50">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <Input 
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Type a message..."
            className="rounded-full py-2 px-4 text-sm bg-slate-800 border-none focus:ring-1 focus:ring-violet-500"
          />
          <Button type="submit" className="rounded-full w-10 h-10 p-0 flex items-center justify-center shrink-0">
             <svg className="w-4 h-4 translate-x-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg>
          </Button>
        </form>
      </div>
    </div>
  );
};

export default Chat;